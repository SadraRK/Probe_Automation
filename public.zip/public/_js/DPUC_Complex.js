window.addEventListener("load", function () {
    document.querySelector("#ComplexButton").addEventListener("click", function () {
        let radial_res = parseFloat(document.querySelector("#Complex_Number_Setup input[name='radial_res']").value);
        let phase_res = parseFloat(document.querySelector("#Complex_Number_Setup input[name='phase_res']").value);
        let num_trials = parseFloat(document.querySelector("#Complex_Number_Setup input[name='num_trials']").value);
        let wavelength = parseFloat(document.querySelector("#Complex_Number_Setup input[name='wavelength']").value);
        let duty_cycle = parseFloat(document.querySelector("#Complex_Number_Setup input[name='duty_cycle']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        parameters["radial_res"] = radial_res;
        parameters["phase_res"] = phase_res;
        parameters["num_trials"] = num_trials;
        parameters["wavelength"] = wavelength;
        parameters["duty_cycle"] = duty_cycle;
        parameters["action"] = "DPUC_Complex_Numbers";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})