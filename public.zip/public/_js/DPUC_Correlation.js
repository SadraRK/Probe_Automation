window.addEventListener("load", function () {
    // document.querySelector("#CorrDetect").addEventListener("click", function () {
    //     let Input_a = document.querySelector("#Dot_Product_Correlation_Setup input[name='Input_a']").value;
    //     let Input_b = document.querySelector("#Dot_Product_Correlation_Setup input[name='Input_b']").value;
    //
    //     let parameters = {
    //         name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
    //         input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
    //         trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
    //         start_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='startWavelength']").value),
    //         number_of_samples: parseInt(document.querySelector("#laserSweepComponent [name='numberOfSamples']").value),
    //         power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
    //     }
    //
    //     if (parameters.input_channels.length === 0) {
    //         alert("Select atleast one input channel.");
    //         return false;
    //     }
    //     parameters["input_a"] = Input_a;
    //     parameters["input_b"] = Input_b;
    //     parameters["action"] = "DPUC_Corr";
    //
    //     sendWSRequest(parameters).then(data => {
    //         console.log(data)
    //     });
    // })

        document.querySelector("#StrtCorr").addEventListener("click", function () {
        let NUM = parseInt(document.querySelector("#Random_Correlation_Detection input[name= 'NUM']").value);
        let fc = parseInt(document.querySelector("#Random_Correlation_Detection input[name= 'fc']").value);
        let Corr_in = document.querySelector("#Random_Correlation_Detection input[name= 'Corr_in']").value;
        let r = parseFloat(document.querySelector("#Random_Correlation_Detection input[name= 'r']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        if (parameters.input_channels.length === 0) {
            alert("Select at least one input channel.");
            return false;
        }
        parameters["NUM"] = NUM;
        parameters["fc"] = fc;
        parameters["Corr_in"] = Corr_in;
        parameters["r"] = r;
        parameters["action"] = "DPUC_rand_Corr";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})