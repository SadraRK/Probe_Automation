window.addEventListener("load", function () {
    document.querySelector("#MultiplierButton").addEventListener("click", function () {
        let bit_res = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='bit_res']").value);
        let num_trials = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='num_trials']").value);
        let Wavelength = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='Wavelength']").value);
        let duty_cycle = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='duty_cycle']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        parameters["bit_res"] = bit_res;
        parameters["num_trials"] = num_trials;
        parameters["Wavelength"] = Wavelength;
        parameters["duty_cycle"] = duty_cycle;
        parameters["action"] = "DPUC_Homodyne_SimpleMul";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})

window.addEventListener("load", function () {
    document.querySelector("#MultiplierSweepButton").addEventListener("click", function () {
        let bit_res = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='bit_res']").value);
        let num_trials = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='num_trials']").value);
        let Wavelength = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='Wavelength']").value);
        let duty_cycle = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='duty_cycle']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        parameters["bit_res"] = bit_res;
        parameters["num_trials"] = num_trials;
        parameters["Wavelength"] = Wavelength;
        parameters["duty_cycle"] = duty_cycle;
        parameters["action"] = "DPUC_Homodyne_SimpleMul_Sweep";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})

window.addEventListener("load", function () {
    document.querySelector("#MultiplierButton_dotproduct").addEventListener("click", function () {
        let bit_res = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='bit_res']").value);
        let num_trials = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='num_trials']").value);
        let Wavelength = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='Wavelength']").value);
        let duty_cycle = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='duty_cycle']").value);
        let data_length = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='data_length']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        parameters["bit_res"] = bit_res;
        parameters["num_trials"] = num_trials;
        parameters["Wavelength"] = Wavelength;
        parameters["duty_cycle"] = duty_cycle;
        parameters["data_length"] = data_length;
        parameters["action"] = "DPUC_Homodyne_DotProduct";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})
window.addEventListener("load", function () {
    document.querySelector("#PSTest").addEventListener("click", function () {
        let num_trials = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='num_trials']").value);
        let Wavelength = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='Wavelength']").value);
        let duty_cycle = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='duty_cycle']").value);
        let data_length = parseFloat(document.querySelector("#Dot_Product_Real_Multiplication_Setup input[name='data_length']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        }

        parameters["num_trials"] = num_trials;
        parameters["Wavelength"] = Wavelength;
        parameters["duty_cycle"] = duty_cycle;
        parameters["data_length"] = data_length;
        parameters["action"] = "DPUC_test_PS";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})