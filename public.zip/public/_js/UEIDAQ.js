window.addEventListener("load", function () {
    document.querySelector("#DAQSweepButton").addEventListener("click", function () {
        let start_0 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_0']").value);
        let stop_0 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_0']").value);
        let num_0 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_0']").value);

        let start_1 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_1']").value);
        let stop_1 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_1']").value);
        let num_1 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_1']").value);

        let start_2 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_2']").value);
        let stop_2 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_2']").value);
        let num_2 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_2']").value);

        let start_3 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_3']").value);
        let stop_3 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_3']").value);
        let num_3= parseFloat(document.querySelector("#UEIDAQSweep input[name='num_3']").value);

        let start_4 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_4']").value);
        let stop_4 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_4']").value);
        let num_4 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_4']").value);

        let start_5 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_5']").value);
        let stop_5 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_5']").value);
        let num_5 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_5']").value);

        let start_6 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_6']").value);
        let stop_6 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_6']").value);
        let num_6 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_6']").value);

        let start_7 = parseFloat(document.querySelector("#UEIDAQSweep input[name='start_7']").value);
        let stop_7 = parseFloat(document.querySelector("#UEIDAQSweep input[name='stop_7']").value);
        let num_7 = parseFloat(document.querySelector("#UEIDAQSweep input[name='num_7']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            start_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='startWavelength']").value),
            stop_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='stopWavelength']").value),
            number_of_samples: parseInt(document.querySelector("#laserSweepComponent [name='numberOfSamples']").value),
            speed: parseFloat(document.querySelector("#laserSweepComponent [name='speed']").value),
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
            responsivity: parseFloat(document.querySelector("#laserSweepComponent [name='responsivity']").value),
            gain_knob: parseFloat(getSelectedValue(document.querySelector("#laserSweepComponent [name='gainKnob']"))[0]),
            gain: parseInt(getSelectedValue(document.querySelector("#laserSweepComponent [name='gain']"))[0]),
            attn: parseFloat(document.querySelector("#laserSweepComponent [name='attn']").value)
        }

        parameters["start_0"] = start_0;
        parameters["stop_0"] = stop_0;
        parameters["num_0"] = num_0;
        parameters["start_1"] = start_1;
        parameters["stop_1"] = stop_1;
        parameters["num_1"] = num_1;
        parameters["start_2"] = start_2;
        parameters["stop_2"] = stop_2;
        parameters["num_2"] = num_2;
        parameters["start_3"] = start_3;
        parameters["stop_3"] = stop_3;
        parameters["num_3"] = num_3;
        parameters["start_4"] = start_4;
        parameters["stop_4"] = stop_4;
        parameters["num_4"] = num_4;
        parameters["start_5"] = start_5;
        parameters["stop_5"] = stop_5;
        parameters["num_5"] = num_5;
        parameters["start_6"] = start_6;
        parameters["stop_6"] = stop_6;
        parameters["num_6"] = num_6;
        parameters["start_7"] = start_7;
        parameters["stop_7"] = stop_7;
        parameters["num_7"] = num_7;
        parameters["action"] = "DAQ_sweep";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})