function getRandomUuid() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
        let dt = new Date().getTime();
        let r = (dt + Math.random() * 16) % 16 | 0;
        return (c === 'x' ? r : (r & 0x3 | 0x8)).toString(16);
    });
}

function getPromiseWithResolve() {
    let alpha_resolve = null;
    let alpha_reject = null;
    let promise = new Promise(function (resolve, reject) {
        alpha_resolve = resolve;
        alpha_reject = reject;
    });
    promise.resolve = alpha_resolve;
    promise.reject = alpha_reject;
    return promise
}

function addOptionsTo(selector, options) {
    let selectDOM = document.querySelector(selector);
    if (!options) options = JSON.parse(selectDOM.getAttribute("data-select"));
    let resultDOM = []

    if (typeof options === 'string') {
        let opt = document.createElement('option');
        opt.value = options;
        opt.innerHTML = options;
        selectDOM.appendChild(opt);
        return opt;
    }
    if (Array.isArray(options)) {
        for (let i of options) {
            let opt = document.createElement('option');
            opt.value = i;
            opt.innerHTML = i;
            selectDOM.appendChild(opt);
            resultDOM.push(opt);
        }
    }

    return resultDOM;
}

paApp.keyPressed = {};
window.addEventListener("keydown", function (e) {
    if (paApp.keyPressed[e.which + "_timestamp"]) return;
    paApp.keyPressed[e.which + "_timestamp"] = e.timeStamp;
    paApp.keyPressed[e.code + "_timestamp"] = paApp.keyPressed[e.which + "_timestamp"];
})

window.addEventListener("onkeyup", function (e) {
    paApp.keyPressed[e.which + "_duration"] = e.timeStamp - paApp.keyPressed[e.which + "_timestamp"];
    paApp.keyPressed[e.code + "_duration"] = paApp.keyPressed[e.which + "_duration"];
    console.log(paApp.keyPressed[e.code + "_duration"]);
    delete paApp.keyPressed[e.which + "_timestamp"];
    delete paApp.keyPressed[e.code + "_timestamp"];
});
