window.addEventListener("load", function () {
    document.querySelector("#keithLaserSweepButton").addEventListener("click", function () {
        let start_a = parseFloat(document.querySelector("#keith2400SweepComponent input[name='start_a']").value);
        let stop_a = parseFloat(document.querySelector("#keith2400SweepComponent input[name='stop_a']").value);
        let num_a = parseFloat(document.querySelector("#keith2400SweepComponent input[name='num_a']").value);

        let start_b = parseFloat(document.querySelector("#keith2400SweepComponent input[name='start_b']").value);
        let stop_b = parseFloat(document.querySelector("#keith2400SweepComponent input[name='stop_b']").value);
        let num_b = parseFloat(document.querySelector("#keith2400SweepComponent input[name='num_b']").value);

        let parameters = {
            name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
            input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
            trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
            start_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='startWavelength']").value),
            stop_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='stopWavelength']").value),
            number_of_samples: parseInt(document.querySelector("#laserSweepComponent [name='numberOfSamples']").value),
            speed: parseFloat(document.querySelector("#laserSweepComponent [name='speed']").value),
            power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
            responsivity: parseFloat(document.querySelector("#laserSweepComponent [name='responsivity']").value),
            gain_knob: parseFloat(getSelectedValue(document.querySelector("#laserSweepComponent [name='gainKnob']"))[0]),
            gain: parseInt(getSelectedValue(document.querySelector("#laserSweepComponent [name='gain']"))[0]),
            attn: parseFloat(document.querySelector("#laserSweepComponent [name='attn']").value)
        }

        parameters["start_a"] = start_a;
        parameters["stop_a"] = stop_a;
        parameters["num_a"] = num_a;
        parameters["start_b"] = start_b;
        parameters["stop_b"] = stop_b;
        parameters["num_b"] = num_b;
        parameters["action"] = "keith_sweep";

        sendWSRequest(parameters).then(data => {
            console.log(data)
        });
    })
})
