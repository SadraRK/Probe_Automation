function addMultiOptionEvent(element) {
    $(element).mousedown(function (e) {
        e.preventDefault();
        const originalScrollTop = $(this).parent().scrollTop();
        $(this).prop('selected', $(this).prop('selected') ? false : true);
        const self = this;
        $(this).parent().focus();
        setTimeout(function () {
            $(self).parent().scrollTop(originalScrollTop);
        }, 0);
        return false;
    });
}

function getSelectedValue(element) {
    return Array.from(element.selectedOptions).map(i => i.value);
}

function plot_laser_sweep(data) {
    data = data.data;
    let xArr = data['wavelength'];
    delete data['wavelength'];
    let traces = []
    for (const [key, value] of Object.entries(data)) {
        if (key.indexOf("_raw") !== -1) continue;
        traces.push({
            y: value,
            x: xArr,
            type: 'line',
            name: key,
        });
    }
    Plotly.newPlot('laserSweepGraph', traces, {
        title: 'Laser Sweep'
    });
    document.querySelector("[name='findNearbyDeviceStatus']").innerHTML = "Completed"
}

function performLaserSweep() {
    let parameters = {
        name: document.querySelector("#laserSweepComponent [name='nameOfSweep']").value,
        input_channels: getSelectedValue(document.querySelector("#laserSweepComponent [name='inputChannels']")),
        trigger_channel: getSelectedValue(document.querySelector("#laserSweepComponent [name='triggerChannel']"))[0],
        start_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='startWavelength']").value),
        stop_wavelength: parseFloat(document.querySelector("#laserSweepComponent [name='stopWavelength']").value),
        number_of_samples: parseInt(document.querySelector("#laserSweepComponent [name='numberOfSamples']").value),
        speed: parseFloat(document.querySelector("#laserSweepComponent [name='speed']").value),
        power: parseFloat(document.querySelector("#laserSweepComponent [name='power']").value),
        responsivity: parseFloat(document.querySelector("#laserSweepComponent [name='responsivity']").value),
        gain_knob: parseFloat(getSelectedValue(document.querySelector("#laserSweepComponent [name='gainKnob']"))[0]),
        gain: parseInt(getSelectedValue(document.querySelector("#laserSweepComponent [name='gain']"))[0]),
        attn: parseFloat(document.querySelector("#laserSweepComponent [name='attn']").value)
    }

    if (parameters.input_channels.length === 0) {
        alert("Select atleast one input channel.");
        return false;
    }
    document.querySelector("[name='findNearbyDeviceStatus']").innerHTML = "Searching..."
    if (document.querySelector("#laserSweepComponent [name='laserSweepGrid']").checked) {
        parameters["action"] = "grid_laser_sweep";
        parameters["grid_x"] = parseInt(document.querySelector("#laserSweepComponent [name='laserSweepGridXSamples']").value);
        parameters["grid_y"] = parseInt(document.querySelector("#laserSweepComponent [name='laserSweepGridYSamples']").value);
        parameters["step_x"] = parseFloat(document.querySelector("#laserSweepComponent [name='laserSweepGridXStep']").value);
        parameters["step_y"] = parseFloat(document.querySelector("#laserSweepComponent [name='laserSweepGridYStep']").value);
        console.log(parameters)
        sendWSRequest(parameters).then(() => {
            document.querySelector("[name='findNearbyDeviceStatus']").innerHTML = "Completed"
        });
    } else {
        parameters["action"] = "laser_sweep";
        sendWSRequest(parameters).then(plot_laser_sweep);
    }
}

window.addEventListener("load", function () {
    addOptionsTo("#laserSweepComponent select[name=gainKnob]");
    addOptionsTo("#laserSweepComponent select[name=gain]");
    sendWSRequest({action: "DAQDevices.list_channels", channel_type: "ai_physical_chans"})
        .then(data => addOptionsTo("#laserSweepComponent select[name=inputChannels]", data["data"]))
        .then(addMultiOptionEvent);
    sendWSAction("DAQDevices.device.terminals")
        .then(data => addOptionsTo(
            "#laserSweepComponent select[name=triggerChannel]",
            data["data"].filter(i => i.indexOf("PFI") !== -1)
        ));

    websocketSubscription["grid_laser_sweep_sweep"] = plot_laser_sweep;
    document.getElementById("laserSweepButton").addEventListener("click", performLaserSweep);
    document.getElementById("laserSweepStopButton").addEventListener("click", () => sendWSAction({"stop_grid_laser_sweep": true}))
    document.getElementById("laserSweepGridComponent").style.display = "none";
    document.querySelector("#laserSweepComponent input[name='laserSweepGrid']").addEventListener('change', () => {
        if (document.querySelector("#laserSweepComponent input[name='laserSweepGrid']").checked) {
            document.getElementById("laserSweepGridComponent").style.display = "block";
        } else {
            document.getElementById("laserSweepGridComponent").style.display = "none";
        }
    });
});