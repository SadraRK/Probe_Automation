function liveInfoListener(latestInfo) {
    window.paApp.liveInfo = latestInfo.data;

    $(".paLiveInfoPre").each((i, j) => {
        let index = j.getAttribute("data-pa");
        if (latestInfo.data?.hasOwnProperty(index)) j.innerHTML = latestInfo.data[index];
    });

    $(".paJSInfoPre").each((i, j) => {
        let index = j.getAttribute("data-pa").split(".");
        let location = window.paApp;
        for (let part of index) {
            location = typeof location[part] !== "undefined" ? location[part] : undefined
        }
        if (typeof location === "function") {
            j.innerHTML = location.call();
        } else {
            j.innerHTML = String(location);
        }
    });
}

window.addEventListener("load", () => {
    let startLiveInfo = [["get_live_info", true]];

    $(".paLiveInfo").each((i, j) => {
        startLiveInfo.push(["add_to_live_info", j.getAttribute("data-pa")]);
        let preElement = document.createElement("pre");
        let inputElement = document.createElement("input");

        preElement.setAttribute("class", "paLiveInfoPre");
        preElement.setAttribute("data-pa", j.getAttribute("data-pa"));
        inputElement.setAttribute("class", "paLiveInfoInput");
        inputElement.setAttribute("data-pa", j.getAttribute("data-pa"));

        j.appendChild(preElement);
    });

    $(".paJSInfo").each((i, j) => {
        let preElement = document.createElement("pre");
        let inputElement = document.createElement("input");
        j.appendChild(preElement);

        preElement.setAttribute("class", "paJSInfoPre");
        preElement.setAttribute("data-pa", j.getAttribute("data-pa"));
        inputElement.setAttribute("class", "paJSInfoInput");
        inputElement.setAttribute("data-pa", j.getAttribute("data-pa"));

    });

    $(".paLiveInfo[data-editable]").dblclick(function (event) {
        let element = event.currentTarget;
        let value = JSON.parse(element.querySelector(".paLiveInfoPre").innerHTML);

        let newValue = prompt(element.innerText.replace(":", ": "), value);

        if (typeof value === "number") newValue = Number.parseFloat(newValue);
        if (typeof value === "boolean") {
            if (newValue.toLowerCase() === "true") newValue = true;
            else if (newValue.toLowerCase() === "false") newValue = false;
            else return;
        }

        sendWSAction([[element.getAttribute("data-pa"), newValue]])
    })
    sendWSAction(startLiveInfo, "live_info", liveInfoListener);
});

