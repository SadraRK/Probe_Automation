'use strict';
const maximumNumberOfPoints = 100;

function getRandomColor() {
    const letters = '0123456789ABCDEF';
    let color = '#';
    for (let i = 0; i < 6; i++) {
        color += letters[Math.floor(Math.random() * 16)];
    }
    return color;
}

function addAlpha(color, opacity) {
    // coerce values so ti is between 0 and 1.
    var _opacity = Math.round(Math.min(Math.max(opacity || 1, 0), 1) * 255);
    return color + _opacity.toString(16).toUpperCase();
}

window.addEventListener("load", function () {
    const config = {
        type: 'line',
        options: {
            scales: {
                x: {display: false}
            },
            animation: {
                duration: 0
            },
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Photodetector'
                }
            }
        },
    };
    const laserTimeSeriesGraph = new Chart(document.getElementById('laserTimeSeriesGraph'), config);
    laserTimeSeriesGraph.canvas.parentNode.style.height = '50%';
    laserTimeSeriesGraph.canvas.parentNode.style.width = '50%';

    sendWSRequest({action: "DAQDevices.list_channels", channel_type: "ai_physical_chans"})
        .then(data => addOptionsTo("#laserComponent select[name=detectorChannel]", data["data"]));

    window.paApp.websocketSubscription["daq_read"] = function (data) {
        data = data.data;
        delete data.uuid;
        for (let i of Object.keys(data)) {
            if (laserTimeSeriesGraph.data.datasets.map((i) => i.label).indexOf(i) === -1) {
                const randomColor = getRandomColor();
                laserTimeSeriesGraph.data.datasets.push({
                    label: i,
                    data: new Array(laserTimeSeriesGraph.data.labels.length).fill(0),
                    backgroundColor: addAlpha(randomColor, 0.2),
                    borderColor: addAlpha(randomColor, 0.5),
                })
            }
        }
        laserTimeSeriesGraph.data.labels.push(Date.now());
        laserTimeSeriesGraph.data.labels = laserTimeSeriesGraph.data.labels.slice(-maximumNumberOfPoints);
        for (let i of laserTimeSeriesGraph.data.datasets) {
            if (i.label in data) {
                if (i.label in laserTimeSeriesGraph.calibration_values) {
                    i.data.push(data[i.label] - laserTimeSeriesGraph.calibration_values[i.label]);
                } else {
                    i.data.push(data[i.label]);
                }
            } else {
                i.data.push(0);
            }
            i.data = i.data.slice(-maximumNumberOfPoints);
        }
        laserTimeSeriesGraph.update();
    }

    $("button[name='detectorChannelAdd']").click(function () {
        const channel = document.querySelector("select[name='detectorChannel']").selectedOptions[0].text;
        sendWSRequest({action: "get_daq_read", channel: channel, subscription: true})
    });
    $("button[name='detectorChannelRemove']").click(function () {
        const channel = document.querySelector("select[name='detectorChannel']").selectedOptions[0].text;
        sendWSRequest({action: "get_daq_read", channel: channel, subscription: false}).then(() => {
            laserTimeSeriesGraph.data.datasets.splice(laserTimeSeriesGraph.data.datasets.map((i) => i.label).indexOf(channel));
            if (laserTimeSeriesGraph.data.datasets.length === 0) {
                laserTimeSeriesGraph.data.labels = [];
            }
        })
    });
    laserTimeSeriesGraph.calibration_values = {}
    sendWSRequest({'action': 'get_daq_calibration_values'}).then((data) => {
        laserTimeSeriesGraph.calibration_values = data.data;
    })
    $("select[name='detectorChannel']").on('change', function () {
        const channel = document.querySelector("select[name='detectorChannel']").selectedOptions[0].text;
        if (channel in laserTimeSeriesGraph.calibration_values) {
            document.querySelector("input[name='detectorChannelCalibrateValue']").value = laserTimeSeriesGraph.calibration_values[channel];
        } else {
            document.querySelector("input[name='detectorChannelCalibrateValue']").value = null;
        }
    });
    $("button[name='detectorChannelCalibrate']").click(function () {
        const channel = document.querySelector("select[name='detectorChannel']").selectedOptions[0].text;
        sendWSRequest({'action': 'daq_calibration', 'channel': channel}).then((data) => {
            laserTimeSeriesGraph.calibration_values[channel] = data.data;
            document.querySelector("input[name='detectorChannelCalibrateValue']").value = data.data;
        })
    });

    window.laserTimeSeriesGraph = laserTimeSeriesGraph;
})

