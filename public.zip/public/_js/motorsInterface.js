class MotorKey {
    value = 0;
    preValue = 0;
    changeTime = 0;
    setValue = (value) => {
        this.preValue = this.value;
        this.value = value;
        this.changeTime = Date.now();
        if (this.value !== this.preValue) this.onLRChange(this.value, this.preValue);
    };
    onLRChange = () => {
    }
}

function motorKeyDown(e) {
    if (!document.querySelector("input[name=motorKeyControl]").checked) return;

    if (e.code === "ArrowLeft") {
        e.preventDefault();
        paApp.motors.leftRight.setValue(-1);
    }
    if (e.code === "ArrowRight") {
        e.preventDefault();
        paApp.motors.leftRight.setValue(+1);
    }
    if (e.code === "ArrowUp") {
        e.preventDefault();
        paApp.motors.upDown.setValue(+1);
    }
    if (e.code === "ArrowDown") {
        e.preventDefault();
        paApp.motors.upDown.setValue(-1);
    }
}

function motorKeyUp(e) {
    if (e.code === "ArrowLeft" || e.code === "ArrowRight") paApp.motors.leftRight.setValue(0);
    if (e.code === "ArrowUp" || e.code === "ArrowDown") paApp.motors.upDown.setValue(0);
}

window.addEventListener("load", function () {
    paApp.motors = {leftRight: new MotorKey(), upDown: new MotorKey()}
    paApp.motors.leftRight.onLRChange = (value) => sendWSAction({'motorX.extreme': value})
    paApp.motors.upDown.onLRChange = (value) => sendWSAction({'motorY.extreme': value})

    setInterval(function () {
        if (paApp.liveInfo["motorX.extreme"] !== 0 && paApp.motors.leftRight.value === 0) sendWSAction({'motorX.extreme': 0})
        if (paApp.liveInfo["motorY.extreme"] !== 0 && paApp.motors.upDown.value === 0) sendWSAction({'motorY.extreme': 0})
    }, 250);

    document.addEventListener('keydown', motorKeyDown);
    document.addEventListener("keyup", motorKeyUp);

    document.querySelector("button[name='speedUpButton']").addEventListener('click', () => {
        sendWSAction({
            "motorX.speed": Math.min(30, paApp.liveInfo["motorX.speed"] * 10),
            "motorY.speed": Math.min(30, paApp.liveInfo["motorY.speed"] * 10),
        })
    })
    document.querySelector("button[name='speedDownButton']").addEventListener('click', () => {
        sendWSAction({
            "motorX.speed": Math.min(30, paApp.liveInfo["motorX.speed"] / 10),
            "motorY.speed": Math.min(30, paApp.liveInfo["motorY.speed"] / 10),
        })
    })

    document.querySelector("button[name='saveLocationButton']").addEventListener("click", () => {
        let name = document.querySelector("input[name='saveLocationName']").value;
        document.querySelector("input[name='saveLocationName']").value = "";
        name = name.length > 0 ? name : Date.now();
        let option = addOptionsTo("select[name='gotoLocation']", name);
        option.locationData = {
            "motorX.position": window.paApp.liveInfo["motorX.position"],
            "motorY.position": window.paApp.liveInfo["motorY.position"],
        };
    });
    document.querySelector("button[name='goLocationButton']").addEventListener("click", () => {
        let option = document.querySelector("select[name='gotoLocation']").selectedOptions[0];
        if (option) sendWSAction(option.locationData);
    });
    document.querySelector("button[name='deleteLocationButton']").addEventListener("click", () => {
        let option = document.querySelector("select[name='gotoLocation']").selectedOptions[0];
        if (option) option.parentElement.removeChild(option);
    });

    sendWSRequest({action: "DAQDevices.list_channels", channel_type: "ai_physical_chans"})
        .then(data => addOptionsTo("#motorComponent select[name='motorDetectorChannel']", data["data"]));

    document.querySelector("button[name='findNearbyDevice']").addEventListener("click", () => {
        const channel = document.querySelector("#motorComponent select[name='motorDetectorChannel']").selectedOptions[0].text;
        document.querySelector("[name='findNearbyDeviceStatus']").innerHTML = "Searching..."
        sendWSAction({"find_nearby_device": {'signal_channel': channel, 'automax': true}}).then(() => {
            document.querySelector("[name='findNearbyDeviceStatus']").innerHTML = "Completed"
        });
    })

})

