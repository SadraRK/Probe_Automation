"use strict";
let websocketQueue = [];
let websocketCallback = {};
let websocketSubscription = {};
let websocketSendDataLoop = setInterval(websocketSendData, 100);


window.paApp.websocketQueue = websocketQueue;
window.paApp.websocketCallback = websocketCallback;
window.paApp.websocketSubscription = websocketSubscription;
window.paApp.websocketSendDataLoop = websocketSendDataLoop;
window.paApp.websocketReady = false;

websocketSubscription["ping"] = function () {
    console.log("ping successful...");
    window.paApp.websocketReady = true;
}

function websocketSendData() {
    if (window.paApp.websocketReady && websocketQueue.length > 0 && window.paApp.websocket.bufferedAmount === 0) window.paApp.websocket.send(websocketQueue.shift());
}

function processReceivedData(response) {
    let responses = JSON.parse(response.data.toString())
    if (!Array.isArray(responses)) responses = [responses];

    for (let response of responses) {
        if (!response["uuid"]) continue;

        let uuid = response["uuid"];
        if (uuid.length > 16) console.log("Result: ", response);
        if (response["error"]) console.error("Python: ", response);
        if (websocketCallback[uuid]) {
            if (response["error"]) {
                websocketCallback[uuid].reject(response);
            } else {
                websocketCallback[uuid].resolve(response);
            }
            if (uuid !== "0000") delete websocketCallback[uuid];
        }
        if (websocketSubscription[uuid]) websocketSubscription[uuid](response);
    }
}

window.addEventListener('load', function () {
    let webSocket = new WebSocket("ws://localhost:8890");
    webSocket.addEventListener("open", () => webSocket.send(JSON.stringify({action: "ping", uuid: "ping"})));
    webSocket.addEventListener("message", processReceivedData);
    webSocket.addEventListener("close", () => console.log("webSocket connection is closed..."));
    window.paApp.websocket = webSocket;
})

function sendWSAction(action, subscriptionUUID, subscriptionListener) {
    return sendWSRequest({"action": action}, subscriptionUUID, subscriptionListener);
}

function sendWSRequest(value, subscriptionUUID, subscriptionListener) {
    value["uuid"] = getRandomUuid();
    let promise = getPromiseWithResolve();

    if (subscriptionUUID && subscriptionListener) websocketSubscription[subscriptionUUID] = subscriptionListener;

    websocketCallback[value["uuid"]] = promise;
    websocketQueue.push(JSON.stringify(value).toString());

    return promise;
}