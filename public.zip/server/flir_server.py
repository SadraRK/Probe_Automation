from wsgiref.simple_server import make_server

from pyramid.config import Configurator
from pyramid.response import Response

from common.async_warp import async_wrap
from common.asyncio_loop import add_function_to_asyncio_loop
from hardware.flir_camera import FlirCamera


def generate(camera):
    while True:
        frame = camera.__next__()
        yield (b'--frame\r\n'
               b'Content-Type: image/jpeg\r\n\r\n' + frame + b'\r\n\r\n')


def flir_video_feed(request):
    return Response(app_iter=generate(FlirCamera()), content_type="multipart/x-mixed-replace; boundary=frame")


def create_flir_server(port):
    with Configurator() as config:
        config.include('pyramid_chameleon')

        config.add_route('flir_feed', '/flir_feed')
        config.add_view(flir_video_feed, route_name='flir_feed')
        app = config.make_wsgi_app()

    print(f'Video Feed from Camera: http://localhost:{port}')
    server = make_server('localhost', port, app)
    return async_wrap(server.serve_forever)()


def flir_server(port):
    add_function_to_asyncio_loop(create_flir_server(port), run_forever=True)
