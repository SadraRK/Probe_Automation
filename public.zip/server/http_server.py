from wsgiref.simple_server import make_server

from pyramid.config import Configurator
from pyramid.view import view_config

from common.async_warp import async_wrap
from common.asyncio_loop import add_function_to_asyncio_loop


@view_config(route_name='/', renderer='../public/index.pt')
def http_index(request):
    return {}


def create_http_server(port):
    with Configurator() as config:
        config.include('pyramid_chameleon')

        config.add_static_view(name='public', path='../public')
        config.add_route('/', '/')

        config.scan()
        app = config.make_wsgi_app()

    print(f'Main Server: http://localhost:{port}/public/index.html')
    server = make_server('localhost', port, app)
    return async_wrap(server.serve_forever)()


def http_server(port):
    add_function_to_asyncio_loop(create_http_server(port), run_forever=True)
