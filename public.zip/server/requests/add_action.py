import inspect
from typing import Dict, Callable

ACTIONS: Dict[str, object] = {}


def add_action(function: Callable):
    if inspect.isfunction(function) or inspect.ismethod(function):
        ACTIONS[function.__name__] = function
    return function


def add_action_by_name(object_name, class_object):
    ACTIONS[object_name] = class_object


@add_action
def list_all_actions():
    return list(ACTIONS.keys())
