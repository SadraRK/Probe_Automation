import asyncio
import copy
import inspect
import json

from common.get_arg_for_request import get_arg_for_request
from common.run_with_async import run_function
from server.requests.add_action import ACTIONS, add_action


def action_str_to_func(action, action_functions):
    action_split = action.split(".")

    if action_split[0] not in action_functions:
        raise Exception(f'"{action_split[0]}" not found')

    action_object = action_functions[action_split[0]]

    if len(action_split) >= 2:
        for i in range(1, len(action_split)):
            if not hasattr(action_object, action_split[i]):
                raise Exception(f"'{action_split[i]}' not found in {action_split}")

            action_object = getattr(action_object, action_split[i])

    return action_object


async def run_action(action: str, data: object, ws_send=None):
    action_object = action_str_to_func(action, ACTIONS)

    if inspect.ismethod(action_object) or inspect.isfunction(action_object):
        if isinstance(data, list):
            arguments = data
        elif isinstance(data, dict):
            data = copy.deepcopy(data)
            data["ws_send"] = ws_send
            arguments = get_arg_for_request(action_object, data)
        else:
            raise TypeError("unknown data type of data")
        return await run_function(action_object, arguments)
    else:
        return json.loads(json.dumps(action_object))


async def one_time_request_handler(request_json, ws_send=None):
    if "action" not in request_json:
        raise Exception(f"No action found: {request_json}")

    action_to_run = request_json["action"]
    tasks = []
    actions = []
    data = None

    if type(action_to_run) is list:
        for i in action_to_run:
            if type(i) is str:
                tasks.append(run_action(i, {}, ws_send=ws_send))
                actions.append(i)
            elif type(i) is list:
                tasks.append(run_action(i[0], i[1:], ws_send=ws_send))
                actions.append(i[0])
            elif type(i) is dict:
                tasks.append(run_action(i["action"], i, ws_send=ws_send))
                actions.append(i['action'])
            else:
                raise NotImplemented

    elif type(action_to_run) is dict:
        for i in action_to_run:
            if type(action_to_run[i]) in [list, dict]:
                tasks.append(run_action(i, action_to_run[i], ws_send=ws_send))
            else:
                tasks.append(run_action(i, [action_to_run[i]], ws_send=ws_send))

            actions.append(i)

    elif type(action_to_run) is str:
        tasks.append(run_action(action_to_run, request_json, ws_send=ws_send))
        actions.append(action_to_run)

    else:
        raise NotImplemented

    if len(tasks) > 0:
        data = await asyncio.gather(*tasks)
        if type(action_to_run) is list:
            data = data
        elif type(action_to_run) is dict:
            data = {actions[i]: data[i] for i in range(len(tasks))}
        elif type(action_to_run) is str:
            data = data[0]
        else:
            raise NotImplemented

    return data


@add_action
def ping():
    return {"data": "success"}
