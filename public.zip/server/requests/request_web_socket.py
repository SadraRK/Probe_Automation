import json
import traceback
from asyncio import sleep

import websockets

from common.asyncio_loop import add_function_to_asyncio_loop
from server.requests.one_time_request import one_time_request_handler
from server.requests.subscription import run_subscriptions

REQUEST_SERVER = None
REQUESTS_MESSAGES: [str] = []


async def ws_request_handle(websocket, path):
    async for message in websocket:
        REQUESTS_MESSAGES.append(message)


async def one_time_request_message_handler(time_step):
    while True:
        if len(REQUESTS_MESSAGES) > 0:
            message = json.loads(REQUESTS_MESSAGES.pop())
            result = {
                "uuid": message["uuid"] if "uuid" in message else None,
                "request": message,
                "subscription": False,
            }

            print(result["request"])

            try:
                data = await one_time_request_handler(message, ws_send=ws_send)
                result["data"] = json.loads(json.dumps(data))
            except Exception as e:
                result["error"] = str(e)
                result["traceback"] = traceback.format_tb(e.__traceback__)

                print(result["error"])
                for i in result["traceback"]:
                    print(i)

            await ws_send(result)
        else:
            await sleep(time_step)


async def subscription_request_loop(time_step):
    while True:
        subscription_results = await run_subscriptions(time_step)
        if len(subscription_results) > 0:
            await ws_send(subscription_results)
        await sleep(time_step)


async def ws_send(message):
    try:
        for i in REQUEST_SERVER.ws_server.websockets:
            await i.send(json.dumps(message))
    except Exception as e:
        print(e)


def request_socket(port):
    global REQUEST_SERVER
    print(f'Request Socket: ws://localhost:{port}')
    REQUEST_SERVER = websockets.serve(ws_request_handle, 'localhost', port)

    add_function_to_asyncio_loop(REQUEST_SERVER, run_forever=True)

    # Adding One Request Message
    add_function_to_asyncio_loop(one_time_request_message_handler(0.05), run_forever=True)
    add_function_to_asyncio_loop(one_time_request_message_handler(0.1), run_forever=True)

    # Adding Subscriptions
    add_function_to_asyncio_loop(subscription_request_loop(0.01), run_forever=True)
