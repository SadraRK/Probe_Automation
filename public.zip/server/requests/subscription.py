import json
import traceback
from typing import Callable

from common.run_with_async import run_function_with_args

SUBSCRIPTION_LOOP: [[Callable, float, float]] = []


def add_to_subscription_loop(func: Callable, time_step: float):
    for i in SUBSCRIPTION_LOOP:
        if i[0] == func:
            return None

    if time_step < 0.01:
        raise Exception(f"{time_step} < 0.01 not allowed.")

    SUBSCRIPTION_LOOP.append([func, time_step, time_step])


def remove_from_subscription_loop(func: Callable, time_step=None):
    for i in SUBSCRIPTION_LOOP:
        if i[0] == func and (time_step is None or i[1] == time_step):
            SUBSCRIPTION_LOOP.remove(i)


async def run_subscriptions(time_passed):
    results = []
    for i in SUBSCRIPTION_LOOP:
        i[2] = i[2] - time_passed

        if i[2] <= 0:
            result = {"subscription": True}

            try:
                data = await run_function_with_args(i[0])
                result["data"] = json.loads(json.dumps(data))
                if "uuid" in result["data"]:
                    result["uuid"] = result["data"]["uuid"]
            except Exception as e:
                result["error"] = str(e)
                result["traceback"] = traceback.format_tb(e.__traceback__)

            results.append(result)
            i[2] = i[1]

    return results
